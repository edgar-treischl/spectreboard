#' Read Pointer Index File and Return as Data Frame
#'
#' @param data Name of the data
#'
#' @returns A data frame containing the pointer index information.
#' @export
#'
read_pointerindex <- function(data) {

  # Check if the data argument is provided
  rlang::check_required(data)

  #Check if folder pointers exists
  if (!dir.exists(here::here("pointers"))) {
    pointers <- "pointers"
    cli::cli_abort("Function expects a folder called {.field {pointers}} in the root of the project.")
  }

  # list all folder names in the pointers
  folder_names <- list.dirs(path = here::here("pointers"),
                            full.names = FALSE,
                            recursive = FALSE)

  #Check if data is not in folder_names
  if (!data %in% folder_names) {
    cli::cli_abort("Can find folder {.field {data}}.")
  }

  # Load the index.yaml file
  index_path <- paste0("pointers/", data, "/index.yaml")
  index_list <- yaml::yaml.load_file(index_path)


  # Convert the list of entries to a data frame
  index_df <- purrr::map_dfr(index_list, ~{
    tibble::tibble(
      table = .x$table,
      version = .x$version,
      status = .x$status,
      schema_hash = .x$schema_hash,
      data_hash = .x$data_hash,
      path = .x$path %||% NA_character_,       # Handle ~ as NA
      validated_by = .x$validated_by,
      time = as.POSIXct(.x$version),
      branch = .x$branch %||% NA_character_    # Handle ~ as NA
    )
  })

  # Print result
  return(index_df)

}

#read_pointerindex(data = "penguins_raw")



#' Get Latest Pointer File
#'
#' @param table_name Name of the table
#' @param base_dir Base directory for pointers
#'
#' @returns The path to the latest pointer file
#' @export
#'
get_latest_pointer <- function(table_name,
                               base_dir = "pointers/") {
  # List all YAML files for this table (recursively)
  base_dir <- paste0(base_dir, table_name, "/")
  files <- fs::dir_ls(base_dir, recurse = TRUE, glob = "*.yaml")

  # Filter for the target table
  table_files <- files[stringr::str_detect(files, glue::glue("{table_name}_\\d{{4}}-\\d{{2}}-\\d{{2}}T\\d{{2}}-\\d{{2}}-\\d{{2}}\\.yaml$"))]

  # Extract timestamp from filenames
  timestamps <- stringr::str_extract(table_files, "\\d{4}-\\d{2}-\\d{2}T\\d{2}-\\d{2}-\\d{2}")
  datetimes <- lubridate::ymd_hms(stringr::str_replace_all(timestamps, "T", " ") |>
                                    stringr::str_replace_all("-", ":"))

  # Get latest
  latest_file <- table_files[which.max(datetimes)]
  return(latest_file)
}

# Example
#get_latest_pointer("penguins_raw")




#' Read a Pointer File
#'
#' @param data Name of the data
#' @param file File path (if NULL it will read the latest pointer)
#'
#' @returns A list containing the pointer and columns data frames.
#' @export
#'
read_pointer <- function(data,
                         file = NULL) {
  folder_names <- list.dirs(path = here::here("pointers"),
                            full.names = FALSE,
                            recursive = FALSE)

  #Check if data is not in folder_names
  if (!data %in% folder_names) {
    cli::cli_abort("Can find folder {.field {data}}.")
  }

  pointer_path <- paste0("pointers/", data, "/")
  all_pointer <- list.files(pointer_path, pattern = "\\.yaml$", full.names = FALSE)
  #all but index.yml
  all_pointer <- all_pointer[!all_pointer %in% "index.yaml"]

  #Only if user does not provide a file
  if (is.null(file)) {
    pointer_path <- get_latest_pointer(data)
  }

  pointer_data <- yaml::yaml.load_file(pointer_path)

  pointer_df <- tibble::tibble(
    table = pointer_data$table,
    version = pointer_data$version,
    status = pointer_data$validation_status,
    schema_hash = pointer_data$schema_hash,
    data_hash = pointer_data$data_hash,
    validated_by = pointer_data$validated_by,
    git_sha = pointer_data$git_commit_sha
  )

  columns_df <- purrr::map_dfr(pointer_data$metadata$columns, ~tibble::tibble(
    column_name = .x$column_name,
    label = .x$label,
    type = .x$type,
    levels = .x$levels,
    description = .x$description
  ))


  #return both as list
  pointer_list <- list(
    pointer = pointer_df,
    columns = columns_df
  )
  pointer_list
}


#read_pointer(data = "penguins_raw")



# #  Loop Over Many Pointers
#
# library(fs)
#
# # Find all pointer YAMLs
# pointer_files <- fs::dir_ls("pointers/validation_logs", recurse = TRUE, glob = "*.yaml")
#
# # Combine all top-level pointer data
# all_pointers_df <- purrr::map_dfr(pointer_files, function(path) {
#   p <- yaml::yaml.load_file(path)
#   tibble(
#     table = p$table,
#     version = p$version,
#     status = p$validation_status,
#     schema_hash = p$schema_hash,
#     data_hash = p$data_hash,
#     validated_by = p$validated_by,
#     validation_time = as.POSIXct(p$validation_time),
#     git_sha = p$git_commit_sha,
#     path = as.character(path)
#   )
# })
#
# # View
# print(all_pointers_df)

#' Read a Pointer File v2
#'
#' @param data Name of the data
#' @param file File path (if NULL it will read the latest pointer)
#'
#' @returns A list containing the pointer and columns data frames.
#' @export
#'

read_pointer2 <- function(data,
                          file = NULL,
                          read_latest = TRUE) {
  folder_names <- list.dirs(path = here::here("pointers"),
                            full.names = FALSE,
                            recursive = FALSE)

  if (!data %in% folder_names) {
    cli::cli_abort("Can't find folder {.field {data}} in pointers.")
  }

  pointer_path_dir <- fs::path("pointers", data)

  pointer_files <- list.files(pointer_path_dir,
                              pattern = "\\.yaml$",
                              full.names = TRUE)
  pointer_files <- pointer_files[!grepl("index.yaml$", pointer_files)]

  if (length(pointer_files) == 0) {
    cli::cli_abort("No pointer files found for {.field {data}}.")
  }

  # Case 1: file is explicitly provided
  if (!is.null(file)) {
    pointer_path <- fs::path("pointers", data, file)
    if (!fs::file_exists(pointer_path)) {
      cli::cli_abort("File {.file {file}} not found in dataset {.field {data}}.")
    }
  } else {
    # Parse version timestamps from filenames
    versions <- pointer_files |>
      fs::path_file() |>
      stringr::str_remove("\\.yaml$") |>
      stringr::str_extract("[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}-[0-9]{2}-[0-9]{2}") |>
      lubridate::ymd_hms(tz = "UTC")

    if (all(is.na(versions))) {
      cli::cli_abort("Could not parse timestamps from pointer filenames. Check file names.")
    }

    # Sort by timestamp descending
    sorted_idx <- order(versions, decreasing = TRUE)
    sorted_files <- pointer_files[sorted_idx]
    sorted_versions <- versions[sorted_idx]

    if (length(sorted_files) == 1  | isTRUE(read_latest)) {
      pointer_path <- sorted_files[1]
      cli::cli_alert_info("Using the latest pointer: {.file {pointer_path}}")
    } else {
      # Ask user which to use, default = latest
      version_labels <- fs::path_file(sorted_files)
      chosen <- utils::menu(
        choices = c(version_labels, "Use latest (default)"),
        title = glue::glue("Choose a pointer for dataset '{data}':")
      )

      if (chosen == 0 || chosen > length(version_labels)) {
        pointer_path <- sorted_files[1]
        cli::cli_alert_info("ℹ Using most recent pointer: {.file {pointer_path}}")
      } else {
        pointer_path <- sorted_files[chosen]
        cli::cli_alert_info("ℹ Using selected pointer: {.file {pointer_path}}")
      }
    }
  }

  # Load YAML
  pointer_data <- yaml::yaml.load_file(pointer_path)

  pointer_df <- tibble::tibble(
    table = pointer_data$table,
    version = pointer_data$version,
    status = pointer_data$validation_status,
    schema_hash = pointer_data$schema_hash,
    data_hash = pointer_data$data_hash,
    validated_by = pointer_data$validated_by,
    git_sha = pointer_data$git_commit_sha %||% NA_character_
  )

  columns_df <- purrr::map_dfr(pointer_data$metadata$columns, ~tibble::tibble(
    column_name = .x$column_name,
    label = .x$label,
    description = .x$description
  ))

  list(
    pointer = pointer_df,
    columns = columns_df
  )
}


#' Read All Pointer File
#'
#' @param data Name of the data
#'
#' @returns A list containing the pointer and columns data frames.
#' @export
#'

read_all_pointers <- function(data = NULL) {

  folders <- fs::dir_ls(path = "pointers", type = "directory")
  folder_names <- fs::path_file(folders)

  if (is.null(data)) {
    cli::cli_abort(
      "The following folders are available: {.val {folder_names}}"
    )
  }


  # folder_names <- list.dirs(path = here::here("pointers"),
  #                           full.names = FALSE,
  #                           recursive = FALSE)

  if (!data %in% folder_names) {
    cli::cli_abort("Can't find folder {.field {data}} in pointers.")
  }

  pointer_path_dir <- fs::path("pointers", data)

  pointer_files <- list.files(pointer_path_dir,
                              pattern = "\\.yaml$",
                              full.names = TRUE)
  pointer_files <- pointer_files[!grepl("index.yaml$", pointer_files)]

  if (length(pointer_files) == 0) {
    cli::cli_abort("No pointer files found for {.field {data}}.")
  }

  all_pointers <- purrr::map_dfr(pointer_files, function(path) {
    pointer_data <- yaml::yaml.load_file(path)

    tibble::tibble(
      table = pointer_data$table,
      version = pointer_data$version,
      status = pointer_data$validation_status,
      schema_hash = pointer_data$schema_hash,
      data_hash = pointer_data$data_hash,
      validated_by = pointer_data$validated_by,
      git_sha = pointer_data$git_commit_sha %||% NA_character_,
      file = fs::path_file(path)
    )
  })

  all_columns <- purrr::map_dfr(pointer_files, function(path) {
    pointer_data <- yaml::yaml.load_file(path)
    version <- pointer_data$version

    purrr::map_dfr(pointer_data$metadata$columns, ~tibble::tibble(
      version = version,
      column_name = .x$column_name,
      label = .x$label,
      type = .x$type,
      levels = .x$levels,
      description = .x$description
    ))
  })

  list(
    pointers = all_pointers,
    columns = all_columns
  )
}

#read_all_pointers(data = "penguins")
