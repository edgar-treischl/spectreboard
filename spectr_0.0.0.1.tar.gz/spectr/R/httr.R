# library(httr)
# library(keyring)
#
# res <- POST(
#   url = "http://localhost:8000/trigger",
#   body = list(table = "customers"),
#   encode = "form",
#   add_headers(API_KEY = keyring::key_get("gitlab_api"))
# )
#
# content(res)
#
#
#
