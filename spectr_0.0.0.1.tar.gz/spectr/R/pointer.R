#' Push validation report to GitLab
#'
#' @param agent The validation agent object created by pointblank
#' @param table_name The name of the table
#' @param runtime The runtime of the validation
#' @param gitlab_project GitLab project ID (default is "214893")
#' @param gitlab_branch GitLab branch name (default is "main")
#'
#' @returns Message
#' @export
#'
push_validation <- function(
    agent,
    table_name,
    runtime,
    gitlab_project = "216273",
    gitlab_branch = "main"
) {
  # saveRDS(agent, file = "agent.rds")
  # agent <- readRDS("agent.rds")
  # print(agent)
  # pointblank::get_agent_x_list(agent)$validation_set
  temp_file <- fs::file_temp(ext = "html")  # temporary HTML file path
  pointblank::export_report(agent, filename = temp_file)
  html_string <- readLines(temp_file, warn = FALSE) |> paste(collapse = "\n")

  output_dir <- paste0(table_name, "/validation/")
  file_basename <- glue::glue("{table_name}_{runtime}.html")
  file_path <- fs::path(output_dir, file_basename)

  # Connect to GitLab
  glcon <- AmtSchulGit::gitlab_connect()

  # Commit message
  commit_message <- glue::glue("spectre adds {fs::path_file(file_path)}")

  # Push file content directly
  result <- gitlabr::gl_push_file(
    project = gitlab_project,
    file_path = file_path,
    branch = gitlab_branch,
    content = html_string,
    commit_message = commit_message
  )

  # Disconnect from GitLab
  gitlabr::unset_gitlab_connection()

  cli::cli_alert_success("Pushed {file_path} to GitLab.")

  return(invisible(result))
}







#' Push Pointer to GitLab
#'
#' @param file_content Content of the pointer
#' @param file_path Path to the file in the GitLab repository
#' @param gitlab_project GitLab project ID (default is "214692")
#' @param gitlab_branch GitLab branch name (default is "main")
#'
#' @returns The result of the push operation
#' @export
#'
push_pointer <- function(
    file_content,
    file_path,
    gitlab_project = "216273",
    gitlab_branch = "main"
) {
  # Connect to GitLab
  glcon <- AmtSchulGit::gitlab_connect()

  # Commit message
  commit_message <- glue::glue("spectre adds {fs::path_file(file_path)}")

  # Push file content directly
  result <- gitlabr::gl_push_file(
    project = gitlab_project,
    file_path = file_path,
    branch = gitlab_branch,
    content = file_content,
    commit_message = commit_message
  )

  # Disconnect from GitLab
  gitlabr::unset_gitlab_connection()

  cli::cli_alert_success("Pushed {file_path} to GitLab.")

  return(invisible(result))
}

#' Push YML Pipe to GitLab
#'
#' @param table_name Table name
#' @param file_content Content of the YML file
#' @param runtime Run time
#' @param gitlab_project GitLab project ID (default is "216117")
#' @param gitlab_branch GitLab branch name (default is "main")
#'
#' @returns The result of the push operation
#' @export
#'

push_ymlpipe <- function(
    table_name,
    file_content,
    runtime,
    gitlab_project = "216273",
    gitlab_branch = "main"
) {
  # Connect to GitLab
  glcon <- AmtSchulGit::gitlab_connect()

  # Create file path
  file_basename <- glue::glue("pipe_{table_name}.yml")
  gitlab_file_path <- fs::path(table_name, file_basename)

  # Commit message (was using `file_path`, which isn't defined—use `gitlab_file_path`)
  commit_message <- glue::glue("spectre a/m {fs::path_file(gitlab_file_path)}")

  # Push file content directly to GitLab
  result <- gitlabr::gl_push_file(
    project = gitlab_project,
    file_path = gitlab_file_path,
    branch = gitlab_branch,
    content = file_content,
    commit_message = commit_message
  )

  # Disconnect from GitLab
  gitlabr::unset_gitlab_connection()

  # Inform the user
  cli::cli_alert_success("Pushed pipe for {.field {table_name}} to GitLab.")

  return(invisible(result))
}


#' Create Validation Pointer
#'
#' @param table_name Table name
#' @param column_metadata Data frame with column metadata
#' @param validation_status Validation status (e.g., "passed", "failed")
#' @param runtime Run time
#' @param schema_hash Hash of the schema
#' @param data_hash Hash of the data
#' @param errors List of errors
#' @param output_format Output format (either "yaml" or "json")
#' @param output_dir Directory to save the output file
#' @param git_commit Whether to commit to Git
#' @param validated_by Name of the person who validated
#' @param local_export Whether to export locally
#'
#' @returns A list containing the validation pointer
#' @export
#'
create_pointer <- function(
    table_name,
    column_metadata,
    validation_status = "passed",
    runtime,
    schema_hash = NULL,
    data_hash = NULL,
    output_format = c("yaml", "json"),
    output_dir = "validation_logs",
    git_commit = TRUE,
    validated_by = "Unknown",
    local_export = TRUE
) {
  output_format <- match.arg(output_format)

  # Build metadata
  metadata <- list(
    dataset_name = table_name,
    version = runtime,
    validated_by = validated_by,
    columns = apply(column_metadata, 1, function(row) {
      list(
        column_name = row["column_name"],
        label = row["label"],
        description = row["description"],
        type = row["type"],
        levels = row["levels"]
      )
    })
  )

  # Build pointer
  pointer <- list(
    table = table_name,
    version = runtime,
    validation_status = validation_status,
    schema_hash = schema_hash,
    data_hash = data_hash,
    validated_by = validated_by,
    metadata = metadata
  )

  output_dir <- "penguins"

  file_basename <- glue::glue("{table_name}_{runtime}.{output_format}")
  file_path <- fs::path(output_dir, file_basename)

  # Convert to in-memory string
  if (output_format == "yaml") {
    pointer_text <- yaml::as.yaml(pointer)
  } else {
    pointer_text <- jsonlite::toJSON(pointer, pretty = TRUE, auto_unbox = TRUE)
  }

  # Optionally write to disk
  if (local_export) {
    fs::dir_create(output_dir)
    writeLines(pointer_text, file_path)
    cli::cli_alert_success("✅ Pointer saved: {file_path}")
  }

  # Push to GitLab
  if (git_commit) {
    cli::cli_alert_info("Pushing pointer to GitLab...")

    gitlab_file_path <- fs::path(table_name, "pointers", file_basename)

    commit_sha <- push_pointer(
      file_content = pointer_text,
      file_path = gitlab_file_path
    )

    #pointer$git_commit_sha <- commit_sha
  }

  pointer$git_file_path <- file_path

  invisible(pointer)
}




#' Update the validation index
#'
#' @param table_name Table name to be updated
#' @param pointer_metadata Pointer metadata
#' @param gitlab_project GitLab project ID
#' @param gitlab_branch GitLab branch name
#'
#' @returns Message indicating success
#' @export
#'

update_validation_index <- function(
    table_name,
    pointer_metadata,
    gitlab_project = "216273",
    gitlab_branch = "main"
) {
  # Connect to GitLab
  index_file_path <- paste0(table_name, "/index.yml")

  AmtSchulGit::gitlab_connect()

  # Check if index.yaml exists
  file_exists_in_gitlab <- function(file_path, project, ref = "main") {
    tryCatch({
      gitlabr::gl_get_file(file_path = file_path, project = project, ref = ref)
      TRUE
    }, error = function(e) {
      FALSE
    })
  }

  index_exists <- file_exists_in_gitlab(
    file_path = index_file_path,
    project = gitlab_project,
    ref = gitlab_branch
  )


  # If it exists, read it; otherwise start empty
  if (index_exists) {
    index_text <- gitlabr::gl_get_file(
      file_path = index_file_path,
      project = gitlab_project,
      ref = gitlab_branch
    )
    #current_index <- yaml::yaml.load(index_text$content)
    current_index <- yaml::yaml.load(index_text)

  } else {
    current_index <- list()
  }

  # Create a new entry
  new_entry <- list(
    table = table_name,
    version = pointer_metadata$version,
    status = pointer_metadata$validation_status,
    schema_hash = pointer_metadata$schema_hash,
    data_hash = pointer_metadata$data_hash,
    path = pointer_metadata$git_file_path,
    validated_by = pointer_metadata$validated_by,
    #time = as.character(pointer_metadata$validation_time),
    branch = gitlab_branch
  )

  # Append new entry
  updated_index <- append(current_index, list(new_entry))
  updated_yaml <- yaml::as.yaml(updated_index)

  # Push the updated index back to GitLab
  gitlabr::gl_push_file(
    project = gitlab_project,
    file_path = index_file_path,
    branch = gitlab_branch,
    content = updated_yaml,
    commit_message = glue::glue("🔄 Update index.yaml with {table_name} at {new_entry$version}")
  )

  cli::cli_alert_success("📘 Updated central pointer registry: {index_file_path}")

  gitlabr::unset_gitlab_connection()
  return(updated_yaml)
}












