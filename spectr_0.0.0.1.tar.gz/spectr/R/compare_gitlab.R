#' Update Global Index
#'
#' @param input The input data to be updated.
#' @param gitlab_project GitLab project ID (default is "216273")
#' @param gitlab_branch GitLab branch name (default is "main")
#' @param git_commit Commit the changes to GitLab (default is TRUE)
#'
#' @returns A message
#' @export
#'
update_globalindex <- function(input,
                               gitlab_project = "216273",
                               gitlab_branch = "main",
                               git_commit = TRUE) {
  # Get the content of the file from GitLab
  glcon <- AmtSchulGit::gitlab_connect()

  pastglobal <- gitlabr::gl_get_file(project = "216273", file_path = "global_index.yml")
  gitlabr::unset_gitlab_connection()


  # Parse the YAML content
  pastglobal_parsed <- yaml::yaml.load(pastglobal)

  pastglobal_df <- do.call(rbind, pastglobal_parsed) |> as.data.frame()
  pastglobal_df$version <- sapply(pastglobal_df$version, as.character)

  pastglobal_df$version <- lubridate::ymd_hms(pastglobal_df$version)


  pastglobal_df


  # Input
  newcontent_parsed <- yaml::yaml.load(newcontent)

  #Har
  new_df <- do.call(rbind, newcontent_parsed) |>  as.data.frame()

  new_df$version <- sapply(new_df$version, as.character)

  # Convert 'version' column to DateTime format for comparison
  new_df$version <- lubridate::ymd_hms(new_df$version)
  new_df

  # Sort by 'version' in descending order and get the latest entry
  latest_entry <- new_df |>
    dplyr::arrange(dplyr::desc(version)) |>
    dplyr::slice(1)

  table_name <- latest_entry$table

  table_exists <- any(table_name %in% pastglobal_df$table)


  row_index <- which(table_name %in% pastglobal_df$table)

  newerversion <- latest_entry$version > pastglobal_df$version[row_index]



  if (table_exists) {
    if (newerversion) {
      pastglobal_df <- pastglobal_df[-row_index, ]
      pastglobal_df <- pastglobal_df |> dplyr::bind_rows(latest_entry)
      cli::cli_alert_success("Updated: {.val {table_name}}")
    }else {
      pastglobal_df <- dplyr::bind_rows(pastglobal_df, latest_entry)
      cli::cli_alert_success("Added: {.val {table_name}}")
    }
  }else {
    cli::cli_alert_info("Table {.val {table_name}} does not exist in the past global index.")
  }








  if (git_commit) {
    # Convert the data frame to a list
    #pastglobal_list <- split(pastglobal_df, seq(nrow(pastglobal_df)))
    # Ensure version is character
    pastglobal_df$version <- as.character(pastglobal_df$version)

    # Convert each row into a flat, named list (not a list of 1-length vectors)
    pastglobal_list <- lapply(seq_len(nrow(pastglobal_df)), function(i) {
      as.list(unlist(pastglobal_df[i, ], use.names = TRUE))
    })

    # Convert to YAML
    yaml_content <- yaml::as.yaml(pastglobal_list)

    # Create a temporary file using fs
    temp_file <- fs::file_temp(pattern = "index_%.yml")

    # Write the YAML content to the temporary file
    writeLines(yaml_content, temp_file)

    # Print the temporary file path
    glcon <- AmtSchulGit::gitlab_connect()

    # Create file path

    gitlab_file_path <- fs::path("global_index.yml")

    # Commit message (was using `file_path`, which isn't defined—use `gitlab_file_path`)
    commit_message <- glue::glue("spectre a/m {fs::path_file(gitlab_file_path)}")

    # Push file content directly to GitLab
    result <- gitlabr::gl_push_file(
      project = gitlab_project,
      file_path = gitlab_file_path,
      branch = gitlab_branch,
      content = yaml_content,
      commit_message = commit_message
    )

    upload <- result$file_path

    # Disconnect from GitLab
    gitlabr::unset_gitlab_connection()

    # Inform the user
    cli::cli_alert_success("Pushed {.field {upload}} to GitLab.")
  }else {
    return(pastglobal_df)
  }

}

#update_globalindex(input = newcontent, git_commit = TRUE)



