# # library(spectr)
# # library(shiny)
# # library(bslib)
# # library(dplyr)
# # library(ggplot2)
# # library(gt)
# # library(tidyr)
#
#
#
# # Source all modules
# source("R/module_about.R")
# source("R/module_summary.R")
# source("R/module_octopussy.R")
# source("R/module_presencematrix.R")
# source("R/module_typematrixX.R")
# source("R/module_helpers.R")
#
# # Set up image path
# shiny::addResourcePath("spectr", system.file("images", package = "spectr"))
#
#
# cat("Working directory:", getwd(), "\n")
# for (module_file in c("R/module_typematrixX.R", "R/module_presencematrix.R")) {
#   if (file.exists(module_file)) {
#     cat("Module file exists:", module_file, "\n")
#     cat("Last modified:", file.info(module_file)$mtime, "\n")
#     cat("First few lines:\n")
#     cat(readLines(module_file, n=5), sep="\n")
#     cat("\n")
#   } else {
#     cat("Module file NOT found:", module_file, "\n")
#   }
# }
#
# # UI
# ui <- bslib::page_navbar(
#   title = shiny::span(
#     shiny::img(src = "spectr/logo.png", height = "60px", class = "me-2"),
#     "Xplore"
#   ),
#   theme = bslib::bs_theme(
#     version = 5,
#     bootswatch = "lux",
#     primary = "#0d6efd",
#     secondary = "#6c757d",
#     success = "#198754",
#     info = "#0dcaf0",
#     font_scale = 0.9,
#     "enable-transitions" = TRUE,
#     # Add IBM Plex Sans font
#     base_font = bslib::font_google("IBM Plex Sans")
#   ),
#
#   sidebar = bslib::sidebar(
#     width = 300,
#     bg = "#f8f9fa",
#     title = "Controls",
#     class = "shadow-sm rounded",
#
#     bslib::card(
#       class = "border-0",
#       shiny::selectInput("dataset", "Select Data:",
#                          choices = c("penguins_raw", "dataset2"),
#                          selected = "penguins_raw"),
#       shiny::p("Select data to view its pointer and metadata.",
#                class = "text-muted small"),
#       shiny::hr(),
#       shiny::p("Pointers made simple with specter.",
#                class = "text-muted small")
#     )
#   ),
#
#   bslib::nav_panel(
#     title = "About",
#     icon = shiny::icon("info-circle"),
#     aboutUI("about")
#   ),
#
#   bslib::nav_panel(
#     title = "Summary",
#     icon = shiny::icon("table"),
#     summaryUI("summary")
#   ),
#
#   bslib::nav_panel(
#     title = "Validation Report",
#     icon = shiny::icon("check-circle"),
#     validationReportUI("validation")
#   ),
#
#   bslib::nav_panel(
#     title = "Type Matrix",
#     icon = shiny::icon("chart-bar"),
#     typeMatrixUI("type")
#   ),
#
#   bslib::nav_panel(
#     title = "Presence Matrix",
#     icon = shiny::icon("chart-bar"),
#     presenceMatrixUI("presence")
#   )
# )
#
# # Server
# server <- function(input, output, session) {
#   # Reactive value for the selected dataset
#   selected_dataset <- reactive({
#     input$dataset
#   })
#
#   # Initialize all module servers
#   aboutServer("about")
#   summaryServer("summary", selected_dataset)
#   validationReportServer("validation", selected_dataset)
#   typeMatrixServer("type", selected_dataset)
#   presenceMatrixServer("presence", selected_dataset)
# }
#
# # Run the app
# shiny::shinyApp(ui, server)
