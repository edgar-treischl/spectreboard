# glcon <- AmtSchulGit::gitlab_connect()
#
#
#
# project_commits <- gitlabr::gl_get_commits(project = "216273")
#
#
#
#
#
# project_commits$authored_date2 <- lubridate::ymd_hms(project_commits$authored_date, tz = "UTC")
#
# # Sort by the authored_date in descending order
#
# sorted <- project_commits[order(project_commits$authored_date, decreasing = TRUE), ]
#
# sorted <- sorted |> dplyr::filter(message == "spectre a/m pipe_penguins.yml")
#
# latest_commit_id <- sorted$id[1]
# #previous_commit_id <- sorted$id[2]
#
# diff_project <- gitlabr::gl_get_diff(project = "216273",
#                                      commit_sha = latest_commit_id)
#
# #View(diff_project)
#
#
# onefile <- diff_project |> dplyr::filter(new_path == "penguins/pipe_penguins.yml")
#
#
# diff_text <- onefile$diff
#
# diff_text
#
# #Chat
# # Split the diff into lines
# diff_lines <- strsplit(diff_text, "\n")[[1]]
# diff_lines
#
# # Remove the diff markers (lines starting with @@)
# # removed_lines <- grep("^\\-", diff_lines, value = TRUE)
# # added_lines <- grep("^\\+", diff_lines, value = TRUE)
# #
# # # Remove the leading "-" and "+" from the lines for clean formatting.
# # removed_lines <- gsub("^\\-", "", removed_lines)
# # added_lines <- gsub("^\\+", "", added_lines)
# #
# # # Combine removed and added lines while maintaining their diff order.
# # ordered_lines <- c(removed_lines, added_lines)
# #
# # # Create HTML content, with red for removed and green for added lines.
# # html_lines <- sapply(ordered_lines, function(line) {
# #   if (grepl("^\\-", line)) {
# #     paste0("<div style='color: red;'>", line, "</div>")  # Red for removed lines
# #   } else {
# #     paste0("<div style='color: green;'>", line, "</div>")  # Green for added lines
# #   }
# # })
# #
# # # Combine all HTML lines into one string
# # diff_html <- paste(html_lines, collapse = "\n")
# #
# # # Render as HTML output using htmltools
# # diff_html_output <- htmltools::HTML(diff_html)
# #
# # # Display in a browsable format
# # htmltools::browsable(diff_html_output)
# #
# # # Display the output in a browsable format
# # htmltools::browsable(diff_html_output)
# #
# #
# #
# # library(httr)
# # library(jsonlite)
# #
# # gitlab_url <- "https://gitlab.com/api/v4"
# # project_id <- URLencode("group/oddjob") # or use numeric ID
# # from_sha <- "abc123"  # old commit
# # to_sha <- "def456"    # new commit
# # token <- Sys.getenv("GITLAB_PAT")  # store your token safely
# #
# # res <- GET(
# #   url = paste0(gitlab_url, "/projects/", project_id, "/repository/compare"),
# #   query = list(from = from_sha, to = to_sha),
# #   add_headers(Authorization = paste("Bearer", token))
# # )
# #
# # compare_data <- fromJSON(content(res, "text", encoding = "UTF-8"))
