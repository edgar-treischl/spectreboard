# library(shiny)
# library(bslib)

# Source the module files (in a real package, these would be exported from the package)
#source("R/scatterplot_module.R")

#' Modern UI function for the application
#' @export
app_ui <- function() {
  bslib::page_sidebar(
    title = "Palmer Penguins App",
    sidebar = bslib::sidebar(
      title = "Controls",
      scatterplotModuleUI("scatter")
    ),

    bslib::navset_card_tab(
      title = "Data Visualizations",
      bslib::nav_panel(
        title = "Scatter Plot",
        value = "scatter_tab",
        bslib::card(
          bslib::card_header("Penguin Measurements"),
          scatterplotOutputUI("scatter")
        )
      ),
      bslib::nav_panel(
        title = "About",
        value = "about_tab",
        bslib::card(
          bslib::card_header("About This App"),
          shiny::p("This is a data explorer for the Palmer Penguins dataset."),
          shiny::p("The dataset contains measurements for three penguin species observed on three islands in the Palmer Archipelago, Antarctica."),
          shiny::p("Data were collected and made available by Dr. Kristen Gorman and the Palmer Station Long Term Ecological Research (LTER) Program."),
          shiny::a("Learn more about the Palmer Penguins dataset",
                   href = "https://allisonhorst.github.io/palmerpenguins/",
                   target = "_blank")
        )
      )
    )
  )
}

#' Main server function for the application
#' @param input Input objects
#' @param output Output objects
#' @param session Session object
#' @export
app_server <- function(input, output, session) {
  # Call the server portion of the scatterplot module
  scatterplotModuleServer("scatter")
}

#' Run the Shiny application
#'
#' This function initializes and runs the Shiny application.
#'
#' @export
run_app <- function() {
  shiny::shinyApp(ui = app_ui(), server = app_server)
}

# # Only run the app if this file is executed directly
# if (interactive()) {
#   run_app()
# }
