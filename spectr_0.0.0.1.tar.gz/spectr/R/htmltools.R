# library(htmltools)
#
# # Example of real diff data from GitLab (your provided data)
# # diff_data <- c(
# #   "@@ -1,6 +1,6 @@",
# #   " # #trigger_validation",
# #   " #",
# #   "-# table <- \"penguins_raw\"",
# #   "+# table <- \"penguins\"",
# #   " #",
# #   " # penguins_metadata <- data.frame(",
# #   " #   column_name = c(",
# #   "@@ -44,8 +44,7 @@",
# #   " #",
# #   " #",
# #   " # # Validate the raw data: All set and Done?",
# #   "-# agent_validated <- octopussy::validate_raw_penguins(data = df)",
# #   "-#",
# #   "+# agent_validated <- octopussy::validate_raw_penguins(data = df, interrogate = TRUE)",
# #   " #",
# #   " #",
# #   "@@ -100,8 +99,7 @@",
# #   " #   runtime = timestamp,",
# #   " #   validation_status = validation_result,",
# #   " #   schema_hash = digest::digest(\"penguins_schema\"),",
# #   "-#   data_hash = digest::digest(\"penguins_2025_04_18\"),",
# #   "-#   errors = NULL,",
# #   "+#   data_hash = digest::digest(\"penguins_2025_04_24\"),",
# #   " #   validated_by = \"Edgar Treischl\",",
# #   " #   local_export = FALSE",
# #   " # )",
# #   "@@ -122,5 +120,40 @@",
# #   " #",
# #   " #",
# #   " #",
# #   "+# # Push Pipe",
# #   "+# #timestamp <- format(Sys.time(), \"%Y-%m-%d|%H:%M:%S\")",
# #   "+# version <- \"v1.0\"",
# #   "+# data_version <- \"Source: Palmerpenguins\"",
# #   "+# label <- paste(timestamp, \"-\", version, \"-\", data_version)",
# #   "+#",
# #   "+# # Add the label to the agent metadata",
# #   "+# agent_validated$label <- label",
# #   "+# #agent_validated$data_source <- \"your_mother\"",
# #   "+#",
# #   "+# temp_file <- fs::file_temp(pattern = \"pipe_raw\", ext = \"yml\")",
# #   "+# temp_file",
# #   "+#",
# #   "+# #pointblank::yaml_write(agent_validated, filename = temp_file, expanded = TRUE)",
# #   "+#",
# #   "+# suppressMessages(",
# #   "+#   pointblank::yaml_write(agent_validated, filename = temp_file, expanded = TRUE)",
# #   "+# )",
# #   "+#",
# #   "+#",
# #   "+# yaml_txt <- readLines(temp_file)",
# #   "+# yaml_content <- paste(yaml_txt, collapse = \"\\n\")",
# #   "+#",
# #   "+#",
# #   "+# push_ymlpipe(",
# #   "+#   table_name = table,",
# #   "+#   file_content = yaml_content,",
# #   "+#   runtime = timestamp,",
# #   "+#   gitlab_project = \"216117\",",
# #   "+#   gitlab_branch = \"main\"",
# #   "+# )"
# # )
#
#
# diff_data <- diff_lines
#
# # Function to visualize the diff as a code block with line numbers and formatting
# visualize_diff <- function(diff_data) {
#   # Create a character vector to store HTML content
#   html_diff <- character()
#
#   # Begin a <pre> tag to create the code block
#   html_diff <- c(html_diff, "<pre><code>")
#
#   # Initialize a line counter for numbering
#   line_counter <- 1
#
#   # Loop through each line in the diff data
#   for (line in diff_data) {
#     # Skip the chunk header lines starting with '@@'
#     if (grepl("^@@", line)) {
#       next
#     }
#
#     # Line number display, aligned with code
#     line_number <- sprintf("<span style='color: grey;'>%3d</span> ", line_counter)
#
#     if (grepl("^\\+", line)) {
#       # Added lines: Green
#       html_diff <- c(html_diff, paste(line_number, "<span style='color: green;'>+ ", substr(line, 2, nchar(line)), "</span>"))
#     } else if (grepl("^\\-", line)) {
#       # Removed lines: Red (without strikethrough)
#       html_diff <- c(html_diff, paste(line_number, "<span style='color: red;'>- ", substr(line, 2, nchar(line)), "</span>"))
#     } else {
#       # Unchanged lines: Gray
#       html_diff <- c(html_diff, paste(line_number, "<span style='color: gray;'>", line, "</span>"))
#     }
#
#     # Increment line counter for the next line
#     line_counter <- line_counter + 1
#   }
#
#   # End the <code> and <pre> tags
#   html_diff <- c(html_diff, "</code></pre>")
#
#   # Combine the HTML parts into one HTML string
#   final_html <- paste(html_diff, collapse = "<br>")
#   return(final_html)
# }
#
# # Generate the HTML diff
# diff_html <- visualize_diff(diff_data)
#
# # Add custom CSS for styling
# custom_css <- "
#   <style>
#     pre {
#       background-color: #f7f7f7;
#       padding: 10px;
#       border-radius: 5px;
#       border: 1px solid #ccc;
#       overflow-x: auto;
#       font-family: 'Courier New', monospace;
#     }
#     code {
#       font-size: 14px;
#     }
#     .added {
#       color: green;
#     }
#     .removed {
#       color: red;
#     }
#     .modified {
#       color: orange;
#     }
#     span {
#       display: inline-block;
#     }
#   </style>
# "
#
# # Combine custom CSS with the diff HTML
# final_html_with_css <- paste(custom_css, diff_html, sep = "")
#
# # Render the final HTML with CSS
# browsable(HTML(final_html_with_css))
