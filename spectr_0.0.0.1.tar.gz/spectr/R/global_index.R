# # Function to find the latest version for a table based on its index.yml
# get_latest_table_metadata <- function(table) {
#   # Read the existing table index YAML file
#   table_index_path <- paste0(table, "/index.yml")
#   table_metadata <- yaml::yaml.load_file(table_index_path)
#   table_metadata_df <- as.data.frame(do.call(rbind, table_metadata))
#
#   table_metadata_df$version <- lubridate::ymd_hms(table_metadata_df$version)
#
#   # Sort entries by version (descending) and select the latest one
#   latest_entry <- table_metadata_df |>
#     dplyr::arrange(dplyr::desc(version)) |>
#     dplyr::slice(1)
#
#   # Return the metadata of the latest entry
#   return(latest_entry)
# }
#
# #get_latest_table_metadata(table = "penguins")
# #get_latest_table_metadata(table = "penguins2")
#
#
# generate_global_index <- function() {
#   table_folders <- fs::dir_ls(here::here(), type = "directory")
#
#   # Use purrr::map to get the latest metadata for each table folder
#   latest_metadata_list <- table_folders |>
#     purrr::map(~ get_latest_table_metadata(basename(.))) |>
#     purrr::compact()
#
#
#   meta_data <- latest_metadata_list |>  dplyr::bind_rows()
#   meta_data
#
#   formatted_metadata <- purrr::pmap(meta_data, function(table, version, status, schema_hash, data_hash, path, validated_by, branch) {
#     list(
#       table = table,
#       version = format(version, "%Y-%m-%dT%H:%M:%S"),
#       status = status,
#       schema_hash = schema_hash,
#       data_hash = data_hash,
#       path = path,
#       validated_by = validated_by,
#       branch = branch
#     )
#   })
#
#   formatted_metadata
#
#   # Write the final global index.yml with proper formatting
#   yaml::write_yaml(formatted_metadata, file = "global_index.yml", indent = 2)
# }
#
#
# #generate_global_index()
#
#
#
#
