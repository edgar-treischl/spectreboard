#' Browse GitLab Function
#'
#' This function opens the specified GitLab URL in the default web browser.
#'
#' @export
#'
browse_gitlab <- function() {
  url <- 'https://gitlab.lrz.de/edgar.treischl/spectr'
  utils::browseURL(url)
}


#' Run the Shiny application
#'
#' This function initializes and runs the Shiny application.
#'
#' @export
run_app <- function() {
  shiny::shinyApp(ui = app_ui(), server = app_server)
}


#' Provide Simple Email Message Body Components
#'
#' The `stock_msg_body2()` function simply provides some stock text for an email
#' message sent. It's an adaption from pointblank version.
#'
#' @return Text suitable for the `msg_body` argument
#'
#'
#' @export

stock_msg_spectre <- function() {

  htmltools::tagList(
    htmltools::HTML("<!-- pointblank stock-msg-body -->"),
    htmltools::HTML(
      blastula::add_image(
        system.file("img", "logo.png", package = "octopussy"),
        width = 250
      )
    ),
    htmltools::tags$br(),
    htmltools::tags$div(
      style = htmltools::css(
        `text-align` = "center",
        `font-size` = "larger"
      ),
      htmltools::HTML("{get_lsv('email/agent_body')[[x$lang]]}")
    ),
    htmltools::tags$br(),
    htmltools::tags$br(),
    htmltools::HTML("{x$report_html_small}"),
    htmltools::tags$br(),
    htmltools::tags$div(
      style = htmltools::css(
        `text-align` = "center",
        `font-size` = "larger"
      ),
      htmltools::HTML("&#9678;")
    )
  ) |>
    as.character()
}

