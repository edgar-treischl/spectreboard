# #trigger_validation
#
# library(spectr)
# library(palmerpenguins)
# table <- "penguins"
#
# penguins_metadata <- data.frame(
#   column_name = c(
#     "species", "island", "bill_length_mm", "bill_depth_mm",
#     "flipper_length_mm", "body_mass_g", "sex", "year"
#   ),
#   label = c(
#     "Penguin species", "Island name", "Bill length (mm)", "Bill depth (mm)",
#     "Flipper length (mm)", "Body mass (g)", "Sex", "Year"
#   ),
#   description = c(
#     "Species of the penguin (Adelie, Chinstrap, Gentoo)",
#     "Island where the penguin was observed (Biscoe, Dream, Torgersen)",
#     "Length of the penguin's bill in millimeters",
#     "Depth of the penguin's bill in millimeters",
#     "Length of the penguin's flipper in millimeters",
#     "Body mass of the penguin in grams",
#     "Sex of the penguin (male or female)",
#     "Year the observation was recorded"
#   ),
#   type = c(
#     "factor",    # species
#     "factor",    # island
#     "numeric",   # bill_length_mm
#     "numeric",   # bill_depth_mm
#     "integer",   # flipper_length_mm
#     "integer",   # body_mass_g
#     "factor",    # sex
#     "integer"    # year
#   ),
#   stringsAsFactors = FALSE
# )
#
# penguins_metadata
#
# # Add a 'levels' column to the metadata
# penguins_metadata$levels <- sapply(penguins_metadata$column_name, function(col) {
#   col_data <- penguins[[col]]
#   if (is.factor(col_data)) {
#     paste(levels(col_data), collapse = ", ")
#   } else {
#     "NA"
#   }
# })
#
# penguins_metadata
#
#
# timestamp <- format(Sys.time(), "%Y-%m-%dT%H-%M-%S")
#
#
#
# df <- palmerpenguins::penguins_raw
#
#
# # Validate the raw data: All set and Done?
# agent_validated <- octopussy::validate_raw_penguins(data = df, interrogate = TRUE)
#
#
#
# agent_validated_list <- pointblank::get_agent_x_list(agent_validated)
# all_passed <- all(agent_validated_list$f_failed == 0)
# all_passed
#
# if (all_passed) {
#   validation_result <- "Pass"
# }else {
#   validation_result <- "Fail"
# }
#
#
#
#
#
# # if (!all_passed) {
# #   mail <- pointblank::email_create(agent_validated,
# #     msg_body = octopussy::stock_msg_body2()
# #   )
# #
# #   # Get email sender and recipient details from config
# #   report_from <- config::get("report_from")
# #   report_to <- config::get("report_to")
# #
# #   # Create a subject with string, table name and date
# #   mailsubject <- paste0(
# #     "Octopussy validation report for ",
# #     deparse(substitute(data)),
# #     " on ",
# #     format(Sys.time(), "%Y-%m-%d %H:%M")
# #   )
# #
# #   # Send the email
# #   mail |>
# #     blastula::smtp_send(
# #       to = report_to,
# #       from = report_from,
# #       subject = mailsubject,
# #       credentials = blastula::creds_file(file = "my_mail_creds")
# #     )
# # }
#
#
#
#
#
# pointer <- create_pointer(
#   table_name = table,
#   column_metadata = penguins_metadata,
#   runtime = timestamp,
#   validation_status = validation_result,
#   schema_hash = digest::digest("penguins_schema"),
#   data_hash = digest::digest("penguins_2025_04_24"),
#   validated_by = "Edgar Treischl",
#   local_export = FALSE
# )
#
#
# pointer
#
#
# indexcontent <- update_validation_index(
#   table_name = table,
#   pointer_metadata = pointer
# )
#
#
# indexcontent
#
# newcontent <- indexcontent
#
# push_validation(agent = agent_validated,
#                 runtime = timestamp,
#                 table_name = table)
#
#
#
#
# # Push Pipe
# #timestamp <- format(Sys.time(), "%Y-%m-%d|%H:%M:%S")
# version <- "v1.0"
# data_version <- "Source: Palmerpenguins"
# label <- paste(timestamp, "-", version, "-", data_version)
#
# # Add the label to the agent metadata
# agent_validated$label <- label
# #agent_validated$data_source <- "your_mother"
#
# temp_file <- fs::file_temp(pattern = "pipe_raw", ext = "yml")
# temp_file
#
# #pointblank::yaml_write(agent_validated, filename = temp_file, expanded = TRUE)
#
# suppressMessages(
#   pointblank::yaml_write(agent_validated, filename = temp_file, expanded = TRUE)
# )
#
#
# yaml_txt <- readLines(temp_file)
# yaml_content <- paste(yaml_txt, collapse = "\n")
# yaml_content
#
#
# push_ymlpipe(
#   table_name = table,
#   file_content = yaml_content,
#   runtime = timestamp,
#   gitlab_project = "216273",
#   gitlab_branch = "main"
# )
#
#
#
#
#
#
#
#
