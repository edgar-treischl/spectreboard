
<!-- README.md is generated from README.Rmd. Please edit that file -->

# spectr <img src="man/figures/logo.png" align="right" width="225"/>

<!-- badges: start -->

<!-- badges: end -->

`spectre` is the undercover agency of your validation pipeline. It
monitors tables via pointer files and launching the appropriate
validation pipeline whenever changes are detected. The results are
stored as versioned metadata pointers (in YAML format) in a dedicated
GitLab repository. Validation pipelines, reports, and pointer data
create a rich meta data for a complete audit trail. `spectr` works
hand-in-hand with the `octopussy` package, which defines the data
preparation and validation pipes, and the `trigger` package which
contains the API for launching workflows. The meta data can be monitored
via the `spectre` shiny app. Whether scheduled or manually triggered,
`spectre` ensures all important steps will be tracked, supporting a
robust, traceable, and reproducible workflow.

## Key Features

- 👓 **Table Monitoring**: Creates and tracks changes in tables via data
  state pointers.

- ⚙️ **Automated Validation Orchestration**  
  `spectre` orchestrates validation pipelines defined in `octopussy` via
  GitLab CI/CD and the `trigger` API to automatically trigger validation
  during key events like pushes or merge requests.

- 💾 **Versioned metadata**  
  Writes validation results and metadata pointers (YAML) to a Git
  repository called `oddjob` for tracking and reproducibility.

- 🚨 **Automated Failure Notifications**  
  When validations fail, users are notified immediately via email,
  enabling fast diagnosis and corrective action.

- 🖥️ **Shiny App**: Monitor validation reports and pointer files with
  ease.

## Installation

You can install the development version of spectr like so:

``` r
remotes::install_git(
  url = "git@gitlab.lrz.de:edgar.treischl/spectr.git",
  credentials = git2r::cred_ssh_key()
)
```
