
<!-- README.md is generated from README.Rmd. Please edit that file -->

# spectreboard

<!-- badges: start -->
<!-- badges: end -->

The goal of spectreboard is to …
